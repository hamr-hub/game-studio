require('./kwaiadapter.js');
ks.momConfig = {
    ["IAPEnable"]: false,
    ["IAAEnable"]: true,
    ["VibrationEnable"]: true,
    ["LeaderboardEnable"]: false,
    ["EmailEnable"]: false,
    ["ReviewEnable"]: false,
    ["ExitEnable"]: false,
    ["CloudArchiveEnable"]: false,
    ["FloatAdEnable"]: false,
    ["ButtonAdEnable"]: false,
    ["ShareEnable"]: true,
    ["LagelEnable"]: false,
    ["MoreGameEnable"]: ks.canIUse("getRecommendGameInfos"),
    ["AddToDeskEnable"]: ks.canIUse("addShortcut"),
    ["AddToSaveEnable"]: ks.canIUse("saveToFavorites"),
    ["SubscribEnable"]: ks.canIUse("showSubscribeMessage"),
    ["MultAdEnable"]: ks.canIUse("ingameContinuousAds"),
    ["Language"]: "pt",
    ["HostURL"]: "https://southamerica-east1-aby-2024.cloudfunctions.net/"
};

ks.adConfig = {
    ["Kwai"]: {
        ["bannerId"]: "ad_de8af1a6a624b8e4",
        ["interId"]: "ad_b8c333eaf8a59b87",
        ["videoId"]: "ad_b2a7593be641e841"
    }
};

// var ThinkingAnalyticsAPI = require("./libs/thinkingdata.mg.wx.min.js");
// ks.ta = new ThinkingAnalyticsAPI({
//   appId: "d78de40d3fb74339ba314bb4bcb2608b",
//   serverUrl: "https://ta-receiver-sgp.g.mi.com",
//   autoTrack: {
//     appShow: true,
//     appHide: true
//   },
//   enableLog: false
// });
// ks.ta.init();
// ks.ta.userSet({
//     ["package"]: "sheepmatch-pt"
// });

function __initApp () {  // init app
globalThis.__wxRequire = require;  // FIX: require cannot work in separate engine 
require('./web-adapter');
const firstScreen = require('./first-screen');


// Polyfills bundle.
require("src/polyfills.bundle.js");

// SystemJS support.
require("src/system.bundle.js");


// Adapt for IOS, swap if opposite
if (canvas){
    var _w = canvas.width;
    var _h = canvas.height;
    if (screen.width < screen.height) {
        if (canvas.width > canvas.height) {
            _w = canvas.height;
            _h = canvas.width;
        }
    } else {
        if (canvas.width < canvas.height) {
            _w = canvas.height;
            _h = canvas.width;
        }
    }
    canvas.width = _w;
    canvas.height = _h;
}
// Adjust initial canvas size
if (canvas && window.devicePixelRatio >= 2) {canvas.width *= 2; canvas.height *= 2;}

const importMap = require("src/import-map.js").default;
System.warmup({
    importMap,
    importMapUrl: 'src/import-map.js',
    defaultHandler: (urlNoSchema) => {
        require('.' + urlNoSchema);
    },
    handlers: {
        'plugin:': (urlNoSchema) => {
            requirePlugin(urlNoSchema);
        },
        'project:': (urlNoSchema) => {
            require(urlNoSchema);
        },
    },
});

firstScreen.start('default', 'default', 'false').then(() => {
    return System.import('./application.js');
}).then((module) => {
    return firstScreen.setProgress(0.2).then(() => Promise.resolve(module));
}).then(({ Application }) => {
    return new Application();
}).then((application) => {
    return firstScreen.setProgress(0.4).then(() => Promise.resolve(application));
}).then((application) => {
    return onApplicationCreated(application);
}).catch((err) => {
    console.error(err);
});

function onApplicationCreated(application) {
    return System.import('cc').then((module) => {
        return firstScreen.setProgress(0.6).then(() => Promise.resolve(module));
    }).then((cc) => {
        require('./engine-adapter');
        return application.init(cc);
    }).then(() => {
        return firstScreen.end().then(() => application.start());
    });
}

}  // init app

// NOTE: on WeChat Android end, we can only get the correct screen size at the second tick of game.
var sysInfo = wx.getSystemInfoSync();
if (sysInfo.platform.toLocaleLowerCase() === 'android') {
    GameGlobal.requestAnimationFrame (__initApp);
} else {
    __initApp();
}
