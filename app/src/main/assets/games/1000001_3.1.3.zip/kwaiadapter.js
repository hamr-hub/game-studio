GameGlobal.wx = ks
wx.onMessage = function() {}
wx.getOpenDataContext = function() {}
globalThis.KSWebAssembly = WebAssembly
globalThis.WXWebAssembly = KSWebAssembly